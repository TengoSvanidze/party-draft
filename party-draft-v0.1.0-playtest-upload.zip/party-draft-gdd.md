> **Current playable build — 1 October 2026:** Six approved positions are active (Ex removed), with all mystery pairs and three clues each, €1,000 carried budgets, 15-second auctions, 30-second choices, button-opened lineups, voting, narrator tie-break, result cards, and rematch. See [current play guide](party-draft-app/README.md), [approved pack](mcu-six-position-pack.json), and [narrator clues](mystery-hints.md). Earlier seven-position examples below are superseded by this six-position playtest.

# Party Draft — Game Design Document

**Version:** 0.13  
**Status:** Core concept defined; open design decisions listed at the end  
**Target:** Online mobile game for iPhone and Android  
**Session:** About 5–15 minutes

## 1. Game vision

Party Draft is a live social drafting game for friends. A group chooses one theme, then competes to build the best themed team and story. A human narrator presents lots in a deliberate order: the most desirable named option first, then less desirable named options. Each player starts with **€1,000 in fictional game money**. Once a player fills a position, they leave that position's auctions. Near the cheapest named lot, the narrator may offer a Mystery Box as an alternative. After all positions are filled, players vote on the best team and story.

The entertainment comes from recognizable reveals, competitive bidding, spending decisions, the narrator's delivery, and the argument over whether a Mystery Box is worth the risk. The winner is chosen by people, not by an automatic performance score.

## 2. Players and roles

| Role | What they do |
| --- | --- |
| Host | Creates the room, selects the theme and settings, admits players, starts the game, and resolves a tied final vote if no separate narrator is present. The host may also draft **or** narrate. |
| Drafter | Bids for one pick in each position, manages a budget, chooses between a known pick and Mystery Box when offered, and votes at the end. Supports 2–6 drafters. |
| Narrator (optional) | Controls the pace, announces named lots, delivers Mystery Box clues, opens reveals, and runs the final vote. This is a human role and does not draft. |
| Spectator (optional) | Watches and votes in the final round, subject to the voting rule selected for the room. |

If there is no separate narrator, the host runs the presentation controls. The app enforces eligibility, budgets, auction timers, and pick assignment; the narrator supplies the performance and banter.

## 3. Match structure

1. **Create room.** Host receives a code, link, and QR code. Friends join from their phones and take drafter or spectator seats. One non-drafter may claim Narrator.
2. **Set up.** Host chooses one theme pack or a custom pack, position list, and timer. Every selected position includes a Mystery Box choice, and every drafter receives €1,000. Everyone sees the rules before the first auction.
3. **Draft by position.** The game presents one position at a time. Within that position, named lots appear in descending desirability order. Only drafters who have not filled that position can participate.
4. **Mystery choice in every position.** Near the cheapest named lot of each position, the eligible player may take the named option or choose a Mystery Box after hearing three clues. The box contents remain hidden until the choice is locked.
5. **Final vote.** Completed teams are shown side by side. Eligible voters each choose one drafter other than themselves. A host or narrator breaks a tie.
6. **Results and rematch.** Show the winner, all teams, money spent and remaining, notable mystery reveals, and a shareable result card. Rematch keeps the room and allows a fresh draft.

## 4. Core position rule

Each drafter has **one slot per position**. Winning a pick fills that slot. That drafter is then ineligible for all later lots of the same position but remains eligible for other positions. A position ends when every drafter has filled its slot, or when the available items are exhausted. Positions can describe a relationship or situation as well as a team function.

For a three-drafter example using a broad **Football Pick** slot:

| Lot | Narrator says | Outcome |
| --- | --- | --- |
| 1 | “Lionel Messi is up.” | John wins the auction. John cannot bid again for this position. |
| 2 | “Next is Zinedine Zidane.” | George wins. Only Nick still needs a pick for this position. |
| 3 | “Álvaro Arbeloa is the known pick. Or, Nick, you can take the Mystery Box.” | Nick chooses the known pick or listens to three clues and takes the box. The box is then revealed. |

Names above illustrate the interaction; shipped packs must use content that the game is permitted to distribute. When the game moves to the next position, John, George, and Nick can all bid again.

## 5. Named-lot auctions

- The narrator announces the **actual name** of every regular lot before bidding starts.
- Within a position, regular lots appear in a fixed descending desirability order set by the pack creator. Everyone can see which lot number is being offered; later regular lots are expected to be less desirable.
- Desirability is judged **from the drafter's point of view**. In a negative position such as “Who Attacks You?”, the first lot is the least dangerous opponent, and later lots are stronger, worse opponents. Those stronger threats have lower starting prices. The narrator still says every regular lot's name.
- Only players with an empty slot for that position can bid. The app rejects unaffordable bids and bids by ineligible players.
- The starting price is shown before the auction. Starting prices are set per lot and may be small amounts such as **€20, €50, or €70**; these are examples, not fixed tiers. Each new bid increases the current bid by at least €1.
- After a bid, an 15-second soft timer restarts. A player can **Yield** to leave the current auction. The high bidder wins when the timer expires or all other eligible players yield.
- The winner pays their bid and receives the named pick immediately. The next lot begins with the remaining eligible players.
- A sole eligible player does not need to bid against themselves. They are offered the next known pick at its stated price or that position's Mystery Box. A price they cannot afford must not trap the match; see the affordability rule below.

## 6. Mystery Box

**Every position has a Mystery Box choice.** It is an alternative to a specific named lot near the lowest-priced lot in that position, usually when the remaining player faces a less desirable known option. It does not replace every auction, and regular lots stay named. The narrator presents the known pick first, then offers the box and gives three clues. The player chooses one. The box opens only after the choice is final.

**Outcome range:** A box can contain a surprisingly good pick, even one much better than the cheap known option, or a genuinely bad pick worse than that known option. For a negative position such as **Who Attacks You?**, a good box reveals a weaker, safer attacker; a bad box reveals a powerful, dangerous attacker. Official packs contain both good and bad possible box outcomes for every position. The game secretly selects the actual contents before the position begins and varies them between matches, so a remembered clue or fixed position does not always give away the answer. A match with several positions should contain at least one good and one bad box outcome, without telling players which positions have them.

**Clue design:** All three clues must be true of the box's actual contents. They should also plausibly fit at least one much stronger or weaker option, so the player can make an exciting wrong guess. Clues are written with the box content in advance; the narrator cannot change the result after hearing the player's decision. The game records the committed contents before the choice and reveals them afterward.

**Price:** The known pick has a posted price. The box price varies between matches and packs, but should sit **near the cheapest named lot's price**, rather than near the premium lots. It can be slightly higher or lower than that cheap pick. For example, if the known final lot starts at €50, a box might be offered for €40 or €70. The player sees the box price before committing, so the gamble concerns the contents, not an unexpected charge. The game never permits a purchase above the player's remaining money. If both options are unaffordable, the player receives a free fallback pick so the position can finish.

**Reveal:** The narrator can pause briefly for guesses, then taps Reveal. The result shows the identity, price paid, and a short explanation of how each clue applied. The player keeps the revealed pick even if it was worse than expected.

The first release should use curated, prewritten box outcomes for every official position. Custom packs can support host-authored outcomes and three clues per outcome, with the chosen answer hidden from drafters. The host/narrator should not be a drafter in that mode.

## 7. Budget and pricing

Every drafter starts with **€1,000** in fictional game money. Spending is permanent for that match. Players can see their own remaining balance and everyone else's balance during auctions. Position slot counts are visible so players can judge future needs. Euro amounts are game values only; there are no real-money purchases or cash prizes in the core game.

Pack creators choose a starting price for each named lot and a nearby price for each Mystery Box. Example opening prices include **€20, €50, and €70**. Actual winning bids may be much higher. In helpful positions, more desirable picks generally start higher. In a negative position, the price reverses: a weaker threat is safer and costs more, while a stronger threat is cheaper. Each pack must be checked against the €1,000 budget so an early expensive win still leaves a reasonable path to later positions; a player can never bid or buy above their remaining balance.

## 8. Voting and winner

When drafting ends, the game displays each player's complete lineup, including any negative position such as the character attacking them, plus total spend. Drafters vote for one other drafter based on whose overall lineup and story they like best. A dangerous opponent can hurt a lineup in the debate, but there is no automatic penalty or score. Spectators may vote if the host enabled spectator voting before the match; the room must show whether their votes count. Voters cannot change their ballot once all votes are in. The app reveals the tally simultaneously. Most votes wins. A tie is decided by the narrator, or by the host when there is no separate narrator. If the host is a tied drafter, use a neutral spectator if available; otherwise the tied result is shared rather than allowing a self-serving tiebreak.

The result card includes theme, winner, each roster, money spent, and the most memorable Mystery Box reveal. Rematch resets picks, budget, and votes, and can reuse the theme with a reshuffled or alternate pack.

## 9. Content and themes

V1 should ship with a small set of generic, safe-to-use themes with curated position lineups and prepared boxes. Candidate themes: Roommates, Movie Night, Food Court, Dream Trip, Superhero Archetypes, Villain Archetypes, Party Guests, Survival Crew, School Club, and Office Team. Each theme needs enough options per position for up to six drafters, plus alternatives so rematches are not identical. **New themes will be added over time**, so theme content must be data-driven rather than hard-coded into the game screens.

The football example is a strong demonstration of the format, but a shipped pack using real player names, images, club marks, or statistics needs a separate content and rights review. A generic football archetype pack can launch without relying on those assets.

**First gameplay theme candidate - Marvel (MCU films only):** Use recognizable characters in their prime, iconic MCU film portrayals. The first pack centers on the Avengers, Guardians, and major film villains. Clues and abilities come from MCU feature films; comics, television series, games, and separate X-Men or Deadpool film continuities are outside this pack. Characters who also appear in television remain eligible through their MCU film portrayals. Do not put film titles or release years on player-facing character cards; keep film references in the narrator guide for content checks. The positions should create a funny personal story, not just a combat lineup. Proposed position pool:

| Position shown to players | What voters imagine |
| --- | --- |
| **Who Makes Your Plan?** | The strategist you trust to think ahead. |
| **Who Defends You?** | The one who protects you when things go wrong. |
| **Who Attacks Your Opponent?** | Your offensive pick against someone else's team. |
| **Your Boyfriend (BF)** | A romantic pick whose fit will cause debate. |
| **Your Best Friend** | The person you would actually want beside you. |
| **Your Ex** | A past relationship that might help or complicate the story. |
| **Who Attacks You?** | A negative slot: the opponent your team must survive. |

Every drafter gets one pick in each selected position, then sits out that position's remaining auctions. **Each selected position includes its own Mystery Box choice.** The host can choose a shorter subset for a 5–15 minute game or use all seven for a longer match. In **Who Attacks You?**, the safer, weaker attacker is offered first and costs more; later, stronger attackers are cheaper because they are worse for the drafter. For example, three threats could start at **€70, €50, and €20** as their danger rises. The narrator can read a short prompt for each position to invite arguments. This is a concept for testing the game loop, not a cleared public content pack. Before distributing a built-in Marvel pack, obtain appropriate rights and review the proposed character names, art, logos, and other branded content. A public starter pack can instead use original superhero archetypes while keeping the same rules.

Custom packs let the host enter the theme, positions, ordered named picks, prices, optional position prompts, and optional Mystery Box contents and clues. The setup screen should flag missing picks, duplicate names, impossible prices, and boxes without three clues before the match starts.

Each official theme pack has a stable ID and version, localized title and description, ordered positions and lots, optional prompts, starting prices, good and bad Mystery Box outcomes with clues for each position, and a publication state. New packs can be published to the theme catalog without changing auction rules. Rooms keep the pack version they started with, so a later content update cannot change an ongoing draft. A pack is validated before publication for enough picks, descending order, affordable prices, a box choice in every position, and complete mystery clues.

## 10. Languages

The app supports **English and Georgian** from its first release. Each player chooses their own interface language; players in the same room can use different languages. Buttons, rules, room messages, theme names, position names and prompts, lot labels, clues, voting text, and share card text must come from localized content rather than being embedded in code. Euro values remain numerically identical across languages and are formatted clearly as € amounts.

English is the initial source copy. **The user will supply and approve Georgian translations**; the development process must not rely on machine-generated Georgian as final copy. The content workflow should export all English strings for translation and import the supplied Georgian strings without changing IDs or game logic. Before a new official theme is shown in Georgian, its Georgian strings should be complete and reviewed. Until then, it can appear in English with a visible language fallback. User-made custom packs display the text their creator entered; the app does not automatically translate them.

## 11. Mobile experience

**Smoothness is a core product requirement.** Use [Apple's Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/) as the design reference, with platform-appropriate behavior on Android. Target consistent 60 fps, immediate local tap feedback, stable controls during updates, brief transitions, and system Reduce Motion support. Motion must never delay submitting a bid, change a deadline, or falsely confirm a purchase. Keep photos sized and cached appropriately without exposing hidden mystery assets. Respect touch target sizes, safe areas, larger text, and English/Georgian layout needs. The screen design specification defines proposed timings and real-device acceptance checks; smoothness has not yet been measured in a working app.

The main draft screen centers the current lot name or Mystery Box, position name and optional prompt, starting or current price, countdown, and one clear primary action: Bid, Yield, Take Known Pick, or Take Mystery Box. A compact roster strip shows filled and empty positions and remaining budget. Other players' eligibility is visible.

Narrator controls are simple, large buttons: Present Lot, Show Clue 1–3, Open Bidding, Pause, Reveal, Next Lot, and Start Vote. Reveals get short animation and sound, with a reduced-motion option. Reactions from players and spectators appear briefly without covering the bid controls.

The room should recover from a dropped connection. Rejoining by the same seat restores budget and roster. An auction pauses briefly if the high bidder disconnects; the narrator or host can resume or skip after a timeout. The app records each completed lot so a reconnect cannot duplicate a purchase.

## 12. V1 scope

The first complete version includes online rooms for iPhone and Android, code/link/QR joining, 2–6 drafters, optional narrator and spectators, one theme per match, curated and custom packs, a catalog that supports later theme additions, English and user-supplied Georgian, playful themed positions, one pick per player per position, descending named lots, bidding and yielding, a good-or-bad Mystery Box choice in every position, three clue reveals, €1,000 budget enforcement, final voting, results, share card, and rematch.

Ideas for later releases: trades, sealed bids, audience awards, alternate auction formats, narrator soundboard, and richer theme packs. These should not delay the first playable version.

## 13. Open decisions before implementation

1. **Mystery timing:** Every position has a box choice; should it always go to the last eligible player, or can it sometimes be offered while multiple drafters are still eligible?
2. **Mystery pricing control:** Is the near-lowest-lot box price set by the pack before the match, or may the narrator choose it within a permitted range? The document currently assumes the player sees a posted price before choosing.
3. **Match length:** Which four or five positions from the seven-position Marvel pool should make up the default 5–15 minute match? The full seven-position version can be a longer mode.
4. **Spectator voting:** Should spectators' votes count equally with drafter votes, or should they only give a separate audience award?

These are product decisions, not blockers to documenting the game. The first playable build can use the stated defaults, then tune them from actual matches.

## 14. First playable content pack

The first English sample is **Marvel: Your Chaotic Lineup**, prepared for three drafters and a separate human narrator. Pack version 0.2 uses **MCU feature films only**, with all seven proposed positions, 21 regular named lots, and 14 possible Mystery Box outcomes. Every position has one good and one bad possible outcome sharing the same three truthful clues. Main lots include Iron Man, Captain America, Thor, Hulk, Black Panther, Groot, and Thanos. Mystery pairs include Doctor Strange/Drax for planning and Vision/Ultron for boyfriend. A bad outcome is a poor fit for that position, not necessarily an obscure or powerless character. This is a content prototype; prices, desirability rankings, and pacing still need a real playtest.

- [Narrator guide](marvel-playtest-narrator.md): full auction script, hidden answers, clue explanations, no-bid defaults, and a worked spending example.
- [Player sheet](marvel-playtest-player.md): rules and blank roster, without future lots or Mystery Box answers.
- [Structured content pack](marvel-playtest-pack.json): stable content IDs, English strings, and empty Georgian fields for user translation. It includes hidden answers and is an authoring file, not a public client payload.

For this first test, the last unfilled drafter in each position receives the Mystery Box choice. Regular opening prices are EUR 70, EUR 50, and EUR 20. Box offers range from EUR 15 to EUR 30 and are selected independently of contents. The narrator commits all box outcomes before the first bid, using a random mix with at least one good and one bad outcome. The full seven-position test may take 15-25 minutes; a four-position quick option uses Plan, Defender, Best Friend, and Who Attacks You. These are estimates to measure, not verified session lengths.

The sample uses drafter votes and a narrator tiebreak; spectators watch for now. It also includes provisional handling of no-bid lots and unaffordable final choices. These choices make the sample runnable and can be revised from observed play. No Georgian wording has been supplied or generated. The pack does not yet contain enough regular lots for four-to-six-player matches.

## 15. First screen design

The first visual proposal uses a near-black background, large typographic character cards, restrained orange actions, and a darker private narrator panel with pale amber labels. Characters appear in their prime, iconic MCU film portrayals. Player-facing cards show the character and a brief role description without a film title or release year; the narrator guide retains film references for content checks. Three static previews cover the player's live auction, the player's final Mystery Box choice, and the narrator's private clue controls. These are design artifacts; multiplayer gameplay has not yet been implemented.

The auction screen includes +EUR 1, +EUR 10, and +EUR 50 raise selectors and a bid button showing the exact amount to submit. The player's Mystery Box screen contains clues and prices but no possible answers. The narrator sees the committed answer, publishes clues in order, and cannot reveal the box until the player has locked a choice. Detailed states and control rules are recorded in the [screen design specification](party-draft-screen-design.md). An [HTML preview](party-draft-screen-design.html) assembles the editable vector designs; PNG copies are available for inline phone review.

Character photos are requested for named lots, known final choices, filled roster slots, and revealed mystery results. A sealed mystery uses a generic box until the reveal; its image, filename, alt text, and asset URL must not expose the answer. Use recognizable MCU film appearances under the agreed prime-character rule. The three saved previews now include Iron Man, Star-Lord, and a narrator-only Drax photo. The full image library and roster/reveal screens remain to be built. The [screen audit](screen-audit.md) records the current corrections and remaining work.

## 16. First playable build and playtest changes — 1 October 2026

The local browser prototype in `party-draft-app/` now runs one synchronized planner round for three drafters and a narrator. This supersedes earlier statements that only static screens exist. The remaining six positions and final voting are still future build scope.

The user tested the first build and approved these changes: **15 seconds for regular auctions**, restarting after each accepted bid, and **30 seconds for the mystery choice** after clue 3. A compact **Lineups** button opens a separate panel with all seven slots and a player selector. Keep that list off the main bidding screen; fill slots progressively as purchases settle, and keep mystery identities hidden until reveal.

**No free picks:** A player with no money cannot buy anything. If neither final option is affordable, nothing is charged or assigned; that slot stays empty and displays **X**. At zero budget, unfilled future slots also show X. This supersedes the original table-test free-assignment/fallback rules. If a regular lot receives no bids, it remains unsold and the narrator continues; exhausted lots leave unfilled slots empty.
