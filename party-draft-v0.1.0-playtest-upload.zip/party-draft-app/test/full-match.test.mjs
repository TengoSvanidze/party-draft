import {configureBoxes} from './setup-boxes.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createRoom,joinRoom,act,tick,view,allowedImage,positions,migrateRoom} from '../engine.mjs';
let request=0;
function setup(){const r=createRoom('FULL23','Host',1000);const players=['A','B','C'].map(n=>joinRoom(r,n,1000));let now=1000;const send=(id,type,data={})=>act(r,id,{type,revision:r.revision,requestId:'full-test-'+(++request),...data},now);const host=(type,data)=>send(r.hostId,type,data);const expire=()=>{now=r.deadline;tick(r,now);};configureBoxes(r);return {r,players,send,host,expire};}
function round(c,choice='box'){
 for(let i=0;i<2;i++){c.host('open');c.send(c.players[i].id,'bid',{amount:positions[c.r.positionIndex].lots[i].price});c.expire();c.host('next');}
 for(let i=0;i<3;i++)c.host('clue');c.send(c.players[2].id,'choose',{kind:choice});c.host('reveal');
}
test('complete six-position match, private votes, tie break, and fresh rematch',()=>{
 const c=setup();c.host('start');const boxes=structuredClone(c.r.boxes);
 for(let i=0;i<6;i++){
  assert.equal(c.r.positionIndex,i);const before=c.players.map(p=>p.budget);round(c,i%2?'known':'box');
  assert.equal(c.r.phase,'complete');assert.deepEqual(c.r.boxes,boxes);
  assert.deepEqual(c.players.map(p=>Object.keys(p.roster).length),[i+1,i+1,i+1]);
  assert.equal(c.players[0].budget,before[0]-70);assert.equal(c.players[1].budget,before[1]-50);
  assert.equal(c.players[2].budget,before[2]-(i%2?20:boxes[i].price));
  assert.equal(view(c.r,c.players[0].id).members[1].lineup.filter(s=>s.status==='filled').length,i+1);
  if(i<5){c.host('next-position');assert.ok(c.players.every(p=>p.pick===null));assert.equal(allowedImage(c.r,c.players[0].id,'tony-stark'),true);}
 }
 assert.throws(()=>c.host('next-position'),/wrongPhase/);c.host('open-vote');
 assert.throws(()=>c.send(c.players[0].id,'vote',{targetId:c.players[0].id}),/invalidVote/);
 assert.throws(()=>c.host('vote',{targetId:c.players[0].id}),/ineligible/);
 c.send(c.players[0].id,'vote',{targetId:c.players[1].id});
 const hidden=view(c.r,c.players[2].id);assert.equal(hidden.myVote,null);assert.equal(hidden.voteCounts,null);assert.equal(hidden.votesCast,1);
 assert.throws(()=>c.send(c.players[0].id,'vote',{targetId:c.players[2].id}),/ineligible/);
 c.send(c.players[1].id,'vote',{targetId:c.players[2].id});c.send(c.players[2].id,'vote',{targetId:c.players[0].id});
 assert.equal(c.r.phase,'tiebreak');assert.throws(()=>c.send(c.players[0].id,'break-tie',{targetId:c.players[0].id}),/narratorOnly/);
 assert.throws(()=>c.host('break-tie',{targetId:c.r.hostId}),/invalidVote/);c.host('break-tie',{targetId:c.players[1].id});
 assert.equal(c.r.phase,'results');assert.equal(view(c.r,c.players[0].id).winnerId,c.players[1].id);
 c.host('rematch');assert.equal(c.r.positionIndex,0);assert.equal(c.r.phase,'lobby');assert.deepEqual(c.r.votes,{});assert.equal(c.r.winnerId,null);assert.equal(c.r.round,2);assert.ok(c.players.every(p=>p.budget===1000&&Object.keys(p.roster).length===0));
});
test('majority vote ends match without narrator overriding the winner',()=>{const c=setup();c.r.positionIndex=5;c.r.phase='complete';c.host('open-vote');c.send(c.players[0].id,'vote',{targetId:c.players[1].id});c.send(c.players[1].id,'vote',{targetId:c.players[0].id});c.send(c.players[2].id,'vote',{targetId:c.players[0].id});assert.equal(c.r.winnerId,c.players[0].id);assert.equal(c.r.phase,'results');assert.throws(()=>c.host('break-tie',{targetId:c.players[1].id}),/invalidVote/);});
test('exhausted player keeps bought character and all subsequent slots remain X',()=>{const c=setup();c.host('start');c.host('open');c.send(c.players[0].id,'bid',{amount:1000});c.expire();c.host('next');c.host('open');c.send(c.players[1].id,'bid',{amount:50});c.expire();c.host('next');for(let i=0;i<3;i++)c.host('clue');c.send(c.players[2].id,'choose',{kind:'known'});c.host('reveal');c.host('next-position');const p=view(c.r,c.players[0].id).members[1];assert.equal(p.lineup[0].card.id,'tony-stark');assert.ok(p.lineup.slice(1).every(s=>s.status==='missed'));c.host('open');assert.throws(()=>c.send(c.players[0].id,'bid',{amount:70}),/ineligible/);});
test('no-budget room advances safely to voting without free purchases',()=>{const c=setup();c.host('start');c.r.phase='complete';c.players.forEach(p=>p.budget=0);for(let i=1;i<6;i++){c.host('next-position');assert.equal(c.r.phase,'complete');}c.host('open-vote');assert.equal(c.r.phase,'voting');assert.ok(c.players.every(p=>Object.keys(p.roster).length===0));});
test('all six pairs have three explanations; nemesis good means safer for player',()=>{assert.equal(positions.length,6);assert.ok(!positions.some(p=>p.id==='ex'));for(const p of positions){assert.equal(p.clues.length,3);assert.equal(p.outcomes.length,2);assert.ok(p.outcomes.every(o=>o.explanations.length===3));assert.deepEqual(p.lots.map(l=>l.price),[70,50,20]);}assert.deepEqual(positions[5].outcomes.map(o=>o.id),['korg','thanos']);});
test('future mystery contents and private indices never serialize for players',()=>{const c=setup();c.host('start');const s=view(c.r,c.players[0].id);for(const key of ['boxes','boxIndex','votes'])assert.equal(key in s,false);for(const id of ['hulk','ultron','korg','thanos'])assert.equal(allowedImage(c.r,c.players[0].id,id),false);});
test('old rooms retain seat identities on upgrade and start cleanly',()=>{const c=setup(),ids=c.r.members.map(p=>p.id),host=c.r.hostId;c.r.rulesVersion=2;c.r.phase='complete';c.players[0].budget=17;assert.equal(migrateRoom(c.r),true);assert.deepEqual(c.r.members.map(p=>p.id),ids);assert.equal(c.r.hostId,host);assert.equal(c.r.phase,'lobby');assert.equal(c.r.upgraded,true);assert.ok(c.r.members.every(p=>p.budget===1000));assert.equal(migrateRoom(c.r),false);});
test('assignment upgrade preserves existing sales and locked choices',()=>{for(const final of [false,true]){const c=setup();c.host('start');if(final)round(c);else{c.host('open');c.send(c.players[1].id,'bid',{amount:90});c.expire();}const phase=c.r.phase,budgets=c.players.map(p=>p.budget),boxes=structuredClone(c.r.boxes);c.r.rulesVersion=4;delete c.r.lastBuyerId;assert.equal(migrateRoom(c.r),true);assert.equal(c.r.lastBuyerId,c.players[final?2:1].id);assert.equal(c.r.phase,phase);assert.deepEqual(c.players.map(p=>p.budget),budgets);assert.deepEqual(c.r.boxes,boxes);assert.equal(migrateRoom(c.r),false);}});
