import {act,positions} from '../engine.mjs';
let serial=0;
export function configureBoxes(r,now=1000){
 const send=(type,extra={})=>act(r,r.hostId,{type,revision:r.revision,requestId:'configure-box-'+(++serial),...extra},now);
 positions.forEach((p,i)=>send('set-box',{positionId:p.id,characterId:p.outcomes[i%2].id}));send('lock-boxes');
}
