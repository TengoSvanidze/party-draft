import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {makeServer} from '../server.mjs';

test('HTTP rooms, protected assets, SSE, stale races, and reconnect restore',async()=>{
 const dir=mkdtempSync(path.join(os.tmpdir(),'party-draft-test-')),statePath=path.join(dir,'state.json');let server=makeServer({statePath});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));let origin='http://127.0.0.1:'+server.address().port;
 const req=async(p,body,seat)=>{const res=await fetch(origin+p,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json'}:{}),...(seat?{Authorization:'Bearer '+seat.token}:{})},body:body?JSON.stringify(body):undefined});return {status:res.status,data:await res.json()};};
 try{
  const host=(await req('/api/rooms',{name:'Host'})).data,base='/api/rooms/'+host.code;
  const players=[];for(const name of ['John','George','Nick'])players.push((await req(base+'/join',{name})).data);
  assert.equal((await req(base+'/state')).status,401);
  assert.equal((await req('/assets/drax-reference.jpg')).status,404);
  assert.equal((await req('/engine.mjs')).status,404);
  assert.equal((await req(base+'/image/drax',null,players[0])).status,403);
  let s=(await req(base+'/state',null,host)).data;
  const action=async(seat,type,extra={})=>{const current=(await req(base+'/state',null,seat)).data;return req(base+'/action',{type,revision:current.revision,requestId:crypto.randomUUID(),...extra},seat);};
  for(const row of s.boxSetup)await action(host,'set-box',{positionId:row.positionId,characterId:row.options[0].id});await action(host,'lock-boxes');await action(host,'start');await action(host,'open');
  s=(await req(base+'/state',null,players[0])).data;
  const streamAbort=new AbortController();const stream=await fetch(origin+base+'/events',{headers:{Authorization:'Bearer '+players[0].token},signal:streamAbort.signal});const reader=stream.body.getReader();const first=new TextDecoder().decode((await reader.read()).value);assert.ok(first.includes('"phase":"auction"'));assert.ok(!first.includes('Drax'));streamAbort.abort();
  const race=await Promise.all(players.slice(0,2).map(p=>req(base+'/action',{type:'bid',revision:s.revision,requestId:crypto.randomUUID(),amount:70},p)));
  assert.equal(race.filter(r=>r.status===200).length,1);assert.equal(race.filter(r=>r.data.error==='stateChanged').length,1);
  await action(host,'pause');
  const before=(await req(base+'/state',null,players[0])).data;
  await new Promise(r=>server.close(r));server=makeServer({statePath});await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
  const after=(await req(base+'/state',null,players[0])).data;assert.equal(after.bid.amount,before.bid.amount);assert.equal(after.members[1].budget,1000);assert.equal(after.paused,true);
  assert.ok(!readFileSync(statePath,'utf8').includes(host.token),'tokens must be hashed at rest');
 }finally{await new Promise(r=>server.close(r));rmSync(dir,{recursive:true,force:true});}
});

test('losing the narrator connection pauses the active clock after a brief grace period',async()=>{
 const server=makeServer({statePath:null});await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
 const request=async(p,body,token)=>{const res=await fetch(origin+p,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json'}:{}),...(token?{Authorization:'Bearer '+token}:{})},body:body?JSON.stringify(body):undefined});return res.json();};
 try{
  const host=await request('/api/rooms',{name:'Host'}),base='/api/rooms/'+host.code;
  for(const name of ['A','B','C'])await request(base+'/join',{name});
  const setup=(await request(base+'/state',null,host.token)).boxSetup;for(const row of setup){const current=await request(base+'/state',null,host.token);await request(base+'/action',{type:'set-box',positionId:row.positionId,characterId:row.options[0].id,revision:current.revision,requestId:crypto.randomUUID()},host.token);}
  for(const type of ['lock-boxes','start','open']){const s=await request(base+'/state',null,host.token);await request(base+'/action',{type,revision:s.revision,requestId:crypto.randomUUID()},host.token);}
  const controller=new AbortController(),response=await fetch(origin+base+'/events',{headers:{Authorization:'Bearer '+host.token},signal:controller.signal});await response.body.getReader().read();controller.abort();
  await new Promise(r=>setTimeout(r,1200));const after=await request(base+'/state',null,host.token);assert.equal(after.paused,true);assert.ok(after.remaining>0);assert.equal(after.deadline,null);
 }finally{await new Promise(r=>server.close(r));}
});
