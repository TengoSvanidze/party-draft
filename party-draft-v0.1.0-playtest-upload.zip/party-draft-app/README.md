# Party Draft — six-position playable match

A working browser game for three drafters and one separate human narrator. This build completes the approved MCU match; it is not an App Store release.

## Play

Open **http://localhost:4173/** while the server is running. Choose **Try all four seats on this laptop** for a practice table. These are four real authenticated seats; the narrator's private answers are deliberately visible in this practice view.

1. In the lobby, the narrator privately chooses one of two characters for each of the six mystery boxes, then selects **Lock all six boxes**. All six must be chosen and locked before starting. Locking is final for that match. Everyone starts with €1,000.
2. Bid or yield. Auctions last 15 seconds after the latest bid. A winning bidder sits out the rest of that position.
   If nobody bids, the character is automatically assigned at its starting price to the next eligible drafter after the last buyer, wrapping around room order. For the first purchase, start with the first drafter. Skip filled slots and players who cannot afford the price; only if nobody qualifies does the lot stay unassigned. This order carries across rounds, including mystery purchases, and resets on rematch.
3. The narrator advances through named lots. The last eligible drafter gets the €20 known character or a mystery box costing €15, €20, €25, or €30.
4. Reveal three clues in order. The player then has 30 seconds to choose. The narrator reveals the committed answer after the choice locks.
5. Continue through Planner, Defender, Attacker, Boyfriend, Best Friend, and Who Attacks You. Purchases and budgets carry across all six. The Ex position has been removed.
6. Open the final vote. Each drafter votes once for someone else. Ballots stay private until all votes are in. The narrator resolves a tie between tied players.
7. View/save a PNG result card containing all lineups and money spent, or rematch with fresh budgets and mystery boxes.

**Lineups** opens a sheet with a player selector and all six slots. It does not pause a live timer. Purchased boxes stay sealed until reveal. Missed slots show X; at zero budget all remaining slots stay X. There are no free purchases.

Every draft screen shows the current round number and role name, including the mystery choice and reveal screens.

If several players still need the third lot, it is auctioned normally; any unfilled slots remain X. On choice timeout, the player buys the known pick if affordable, otherwise the box if affordable, otherwise nothing. The displayed fallback explains this before expiry.

## Content

The authoritative pack is ../mcu-six-position-pack.json, matching ../character-selections.json. The narrator reference is ../mystery-hints.md. Each pair shares three indirect, truthful clues, with explanations for both answers. Version 2 removes named people, locations, signature weapons, and explicit metal-limb clues. The narrator locks all six outcomes in the lobby. Prices are assigned independently of the choices. Rematch clears the selections and requires the narrator to choose and lock again. Only the narrator receives setup options and selected identities. Existing running matches retain their old committed contents after upgrade.

Characters are in their prime. In Who Attacks You, Korg is safer and Thanos is dangerous. The named lots remain Green Goblin €70, Ronan €50, and Ego €20 as selected. Rankings are for discussion, not automatic combat scoring.

## Phones on the same Wi-Fi

Open **http://192.168.0.234:4173/** on each phone while the laptop stays awake. This address may change; the server prints its current Wi-Fi address when started. Create the room using that address and share its invite link or six-character code. Keep the narrator screen private. Physical-phone connectivity and touch performance have not yet been verified. No firewall settings were changed.

This build runs locally, not on the public internet. HTTPS hosting remains a separate release step.

## Start later

Double-click Start-Party-Draft.cmd, or run npm start in this folder with Node.js 22+. No packages need installing. Run npm test for the automated checks.

State persists privately in ../../work/party-draft-state.json; seat tokens are hashed there. A page reload resumes the same seat through tab session storage. Closing the tab or switching browsers does not recover the seat. Rooms expire after 24 hours of inactivity. A server restart pauses active clocks. Losing an established narrator or leading-bidder stream pauses the clock after a short grace period; the narrator resumes. Silent network partitions depend on connection-close detection.

The first upgrade from the old single-position prototype keeps seat identities but returns old rooms to a fresh lobby. A private .before-six-rounds backup preserves old saved state.

## Validation and limits

Automated checks cover the complete match, carried budgets/lineups, zero-budget X slots, mystery secrecy, clue gating, both choices, timeouts, stale bids, duplicate requests, pause/resume, majority/tied voting, rematches, migration, protected images, SSE, and restart recovery. A four-seat browser playthrough reaches voting and narrator tie-break.

Still outside this build: configurable 2–6 seats, spectators, trades, theme selection/custom lists, public hosting, durable seat recovery, and native app packaging. English is active; Georgian fields await your translations and fall back to English. New theme content can use the same private pack schema.

## Sources and private data

Photo sources are recorded in ../assets/image-sources.json, ../assets/playable-round-image-sources.json, and ../assets/full-match-image-sources.json. This remains the existing private MCU playtest; public distribution rights are not established. Old seven-position packs and static concepts are historical assets, not live content.

The server sends viewer-specific state and authorizes image access. Keep private packs, the engine, and runtime state outside the public static allowlist.
