import http from 'node:http';
import {readFileSync,writeFileSync,mkdirSync,renameSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';
import {randomBytes,createHash} from 'node:crypto';
import {createRoom,joinRoom,act,view,tick,allowedImage,RuleError,migrateRoom} from './engine.mjs';

const ROOT=path.dirname(fileURLToPath(import.meta.url));
const images={'tony-stark':['iron-man-reference.jpg','image/jpeg'],'star-lord':['star-lord-reference.png','image/png'],'drax':['drax-reference.jpg','image/jpeg'],'nick-fury':['nick-fury-reference.jpg','image/jpeg'],'doctor-strange':['doctor-strange-reference.jpg','image/jpeg']};
const fullPhotos=JSON.parse(readFileSync(path.resolve(ROOT,'../assets/full-match-image-sources.json'),'utf8'));
for(const [id,entry] of Object.entries(fullPhotos))images[id]=[entry.file,entry.type];
const hash=t=>createHash('sha256').update(t).digest('hex');
export function makeServer({statePath=path.resolve(ROOT,'../../work/party-draft-state.json')}={}) {
  const rooms=new Map(), sessions=new Map(),streams=new Map(),rates=new Map();let closing=false;
  if(statePath && existsSync(statePath)) {
    const saved=JSON.parse(readFileSync(statePath,'utf8'));
    for(const r of saved.rooms||[])if(Date.now()-r.updated<86400000){
      // A restart must not silently consume a live auction or choice window.
      if(r.deadline){r.remaining=Math.max(1,r.deadline-saved.savedAt);r.deadline=null;r.paused=true;r.revision++;}
      if(r.rulesVersion<3 && !existsSync(statePath+'.before-six-rounds'))writeFileSync(statePath+'.before-six-rounds',JSON.stringify(saved));
      migrateRoom(r);
      rooms.set(r.code,r);
    }
    for(const [token,s] of saved.sessions||[])if(rooms.has(s.code))sessions.set(token,s);
  }
  const persist=()=>{if(!statePath)return;mkdirSync(path.dirname(statePath),{recursive:true});writeFileSync(statePath+'.tmp',JSON.stringify({savedAt:Date.now(),rooms:[...rooms.values()],sessions:[...sessions]}));renameSync(statePath+'.tmp',statePath);};
  const sendState=(res,r,id)=>res.write(`data: ${JSON.stringify(view(r,id))}\n\n`);
  const broadcast=r=>{persist();for(const [res,s]of streams)if(s.code===r.code)sendState(res,r,s.memberId);};
  const grant=(r,m)=>{const token=randomBytes(32).toString('hex');sessions.set(hash(token),{code:r.code,memberId:m.id});return {token,code:r.code,memberId:m.id};};
  const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
  const body=async req=>{let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>8192)throw new RuleError('invalidRequest');}try{return JSON.parse(raw);}catch{throw new RuleError('invalidRequest');}};
  const nameOf=input=>{if(typeof input.name!=='string')throw new RuleError('invalidName');const name=input.name.trim();if(!name||name.length>24||/[\x00-\x1f<>]/.test(name))throw new RuleError('invalidName');return name;};
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-src 'self'; frame-ancestors 'self'; base-uri 'none'; form-action 'self'");
    try {
      const url=new URL(req.url,'http://local');const route=url.pathname;
      if(req.method==='POST') {
        if(req.headers.origin && req.headers.origin!==`http://${req.headers.host}` && req.headers.origin!==`https://${req.headers.host}`)throw new RuleError('unauthorized');
        if(!String(req.headers['content-type']).startsWith('application/json'))throw new RuleError('invalidRequest');
        const ip=req.socket.remoteAddress;let rate=rates.get(ip);
        if(!rate||Date.now()-rate.start>60000)rates.set(ip,rate={start:Date.now(),n:0});
        if(++rate.n>240)return json(res,429,{error:'slowDown'});
      }
      if(req.method==='POST'&&route==='/api/rooms') {
        if(rooms.size>=100)return json(res,429,{error:'slowDown'});
        const input=await body(req),name=nameOf(input);let code;
        do{code=Array.from(randomBytes(6),b=>'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b%32]).join('');}while(rooms.has(code));
        const r=createRoom(code,name);rooms.set(code,r);const session=grant(r,r.members[0]);persist();return json(res,201,session);
      }
      const match=route.match(/^\/api\/rooms\/([A-Z2-9]{6})(?:\/(join|state|events|action|image)(?:\/([a-z0-9-]+))?)?$/);
      if(match) {
        const [,code,op,imageId]=match,r=rooms.get(code);if(!r)return json(res,404,{error:'roomMissing'});
        if(op==='join'&&req.method==='POST'){const m=joinRoom(r,nameOf(await body(req)));const session=grant(r,m);broadcast(r);return json(res,201,session);}
        const token=String(req.headers.authorization||'').replace(/^Bearer /,'');const session=sessions.get(hash(token));
        if(!session||session.code!==code)return json(res,401,{error:'unauthorized'});
        if(tick(r))broadcast(r);
        if(op==='state'&&req.method==='GET')return json(res,200,view(r,session.memberId));
        if(op==='events'&&req.method==='GET'){
          res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-store','Connection':'keep-alive'});
          streams.set(res,session);sendState(res,r,session.memberId);req.on('close',()=>{
            streams.delete(res);
            const grace=setTimeout(()=>{
              if(closing||[...streams.values()].some(s=>s.code===code&&s.memberId===session.memberId))return;
              if(!r.paused&&r.deadline&&['auction','choice'].includes(r.phase)&&(session.memberId===r.hostId||session.memberId===r.bid?.playerId)){
                r.remaining=Math.max(1,r.deadline-Date.now());r.deadline=null;r.paused=true;r.revision++;r.updated=Date.now();broadcast(r);
              }
            },1000);grace.unref();
          });return;
        }
        if(op==='action'&&req.method==='POST'){
          act(r,session.memberId,await body(req));broadcast(r);return json(res,200,view(r,session.memberId));
        }
        if(op==='image'&&req.method==='GET') {
          if(!allowedImage(r,session.memberId,imageId))return json(res,403,{error:'unauthorized'});
          const info=images[imageId];if(!info)return json(res,404,{error:'imageMissing'});
          const file=path.resolve(ROOT,'../assets',info[0]);if(!existsSync(file))return json(res,404,{error:'imageMissing'});
          res.writeHead(200,{'Content-Type':info[1],'Cache-Control':'private, no-store'});return res.end(readFileSync(file));
        }
        return json(res,404,{error:'notFound'});
      }
      const publicFiles={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/strings.en.json':'strings.en.json','/strings.ka.json':'strings.ka.json'};
      if(req.method==='GET'&&publicFiles[route]) {
        const file=publicFiles[route],type=file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':file.endsWith('.json')?'application/json':'text/html';
        res.writeHead(200,{'Content-Type':type+'; charset=utf-8','Cache-Control':'no-store'});return res.end(readFileSync(path.join(ROOT,'public',file)));
      }
      json(res,404,{error:'notFound'});
    }catch(error){if(!(error instanceof RuleError))console.error('Request failed:',error.message);json(res,error instanceof RuleError?400:500,{error:error.code||'serverError'});}
  });
  const clock=setInterval(()=>{for(const r of rooms.values())if(tick(r))broadcast(r);},100);
  const heartbeat=setInterval(()=>{for(const res of streams.keys())res.write(': ping\n\n');},15000);
  const cleanup=setInterval(()=>{for(const[code,r]of rooms)if(Date.now()-r.updated>86400000){for(const[res,s]of streams)if(s.code===code){res.end();streams.delete(res);}rooms.delete(code);for(const[k,s]of sessions)if(s.code===code)sessions.delete(k);}for(const[ip,r]of rates)if(Date.now()-r.start>60000)rates.delete(ip);persist();},60000);
  server.on('close',()=>{closing=true;clearInterval(clock);clearInterval(heartbeat);clearInterval(cleanup);for(const res of streams.keys())res.end();});
  return server;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const port=Number(process.env.PORT||4173),server=makeServer();
  server.listen(port,'0.0.0.0',()=>{console.log(`Party Draft: http://localhost:${port}`);for(const entries of Object.values(os.networkInterfaces()))for(const a of entries||[])if(a.family==='IPv4'&&!a.internal)console.log(`Same Wi-Fi: http://${a.address}:${port}`);});
}
