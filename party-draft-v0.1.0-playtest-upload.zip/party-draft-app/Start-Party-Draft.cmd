@echo off
pushd "%~dp0"
echo Party Draft will run at http://localhost:4173
echo Leave this window open while playing. Close it to stop the server.
if exist "C:\Program Files\nodejs\node.exe" (
  "C:\Program Files\nodejs\node.exe" server.mjs
) else (
  node server.mjs
)
popd
pause
