# Mystery clues — narrator reference

Version 2: indirect, shared clues for the approved MCU film pairs. The narrator chooses one outcome per position in the lobby and locks all six before the match starts. The same three clues are used whichever character is selected. No character names, signature weapons, or named locations appear in the clues. Explanations below are spoilers for the narrator. Role quality is subjective; the vote decides the winner.

## Who Makes Your Plan?

Doctor Strange / Drax

1. **My confidence has put other people in danger.**
   - Doctor Strange: Strange attempts the memory spell despite the risks and interruptions, helping cause the multiverse crisis.
   - Drax: Drax summons Ronan to Knowhere, endangering the Guardians.
2. **I helped hold an enemy in place so someone else could act.**
   - Doctor Strange: Strange restrains Thanos with magical bands during the attempt to remove the gauntlet.
   - Drax: Drax holds Thanos’s leg during the same attempt.
3. **I was gone for years without growing older.**
   - Doctor Strange: Strange disappears in the Snap and returns five years later.
   - Drax: Drax disappears in the Snap and returns five years later.

## Who Defends You?

Peter Parker / Spider-Man / Happy Hogan

1. **Someone far richer than me trusted me with important work.**
   - Peter Parker / Spider-Man: Tony trusts Peter with hero work, equipment, and eventually his legacy.
   - Happy Hogan: Tony trusts Happy as his bodyguard and security associate.
2. **Some of my most useful equipment came from someone else’s workshop.**
   - Peter Parker / Spider-Man: Peter uses technology developed by Stark.
   - Happy Hogan: Happy uses Stark equipment, including the jet.
3. **I tried to keep young people alive when a trip went badly wrong.**
   - Peter Parker / Spider-Man: Peter protects his classmates during their European trip.
   - Happy Hogan: Happy shelters Peter’s school friends during the London attack.

## Who Attacks Your Opponent?

Scarlet Witch / Hawkeye

1. **I was on the wrong side before fighting beside the heroes.**
   - Scarlet Witch: Wanda initially works with HYDRA and Ultron before joining the Avengers.
   - Hawkeye: Clint serves Loki while under the sceptre’s control before rejoining the Avengers.
2. **After losing family, I became someone people had reason to fear.**
   - Scarlet Witch: Wanda’s grief over her lost children drives her violent pursuit of America Chavez in the film Multiverse of Madness.
   - Hawkeye: After his family is erased, Clint becomes the lethal vigilante Ronin.
3. **I have fought friends because I believed I was on the right side.**
   - Scarlet Witch: Wanda fights former Avengers teammates during the airport battle.
   - Hawkeye: Clint fights former Avengers teammates during the airport battle.

## Your Boyfriend

Vision / Ultron

1. **Other people had a purpose in mind for me before I could choose one.**
   - Vision: Vision’s body is intended for Ultron; Stark and Banner then plan to integrate J.A.R.V.I.S. into it.
   - Ultron: Stark and Banner intend Ultron to be a peacekeeping program.
2. **I decided for myself what the world needed.**
   - Vision: Vision chooses to protect life and oppose Ultron.
   - Ultron: Ultron decides humanity must be eliminated in order to achieve peace.
3. **I ended up fighting the person whose ideas helped make me.**
   - Vision: Vision fights Ultron, who designed the synthetic body he inhabits.
   - Ultron: Ultron fights Tony Stark, whose peacekeeping project brought him into being.

## Your Best Friend

Bucky Barnes / Nebula

1. **I was turned into something I never chose to become.**
   - Bucky Barnes: HYDRA turns Bucky into its brainwashed assassin.
   - Nebula: Thanos forcibly rebuilds Nebula and trains her as a weapon.
2. **I once took orders from people I later turned against.**
   - Bucky Barnes: Bucky serves HYDRA under conditioning, then fights against its control.
   - Nebula: Nebula serves Thanos, then turns against him.
3. **Someone I once fought eventually fought on my side.**
   - Bucky Barnes: Bucky fights Steve and Sam before becoming their ally.
   - Nebula: Nebula fights Gamora and the Guardians before becoming their ally.

## Who Attacks You?

Korg / Thanos

1. **I have led others who were willing to fight.**
   - Korg: Korg organises a rebellion among the gladiators on Sakaar.
   - Thanos: Thanos commands armies who fight for him.
2. **I have taken up arms for a future I thought was better.**
   - Korg: Korg fights for freedom from the Grandmaster and later against Thanos.
   - Thanos: Thanos fights to impose the future he believes his plan will create.
3. **I was there when a battle changed the fate of almost everyone.**
   - Korg: Korg fights in the final battle at the Avengers compound.
   - Thanos: Thanos fights in that same final battle.

The box price remains independent of the selected character. Korg is the safer enemy; Thanos is the dangerous one. Georgian fields remain blank for your translations.
